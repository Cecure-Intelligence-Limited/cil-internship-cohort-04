import logging

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)


def handler(event, context):
    func_handler = "This lambda function has been triggered by a step function"
    return func_handler