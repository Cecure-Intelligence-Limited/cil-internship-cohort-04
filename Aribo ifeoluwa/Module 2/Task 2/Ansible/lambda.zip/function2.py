
def handler(event, context):
    func_handler = "This lambda function has been deployed via ansible"
    return func_handler