
from datetime import datetime as dt


def processSuccess(value, context):
    print("Processing...")
    result = {}

    result['Status'] = value['Status']
    result['When'] = dt.now().strftime("%d-%m-%Y %H:%M:%S")
    result['Message'] = "This transaction was successful!"

    return result
