# Lambda Python Function

def test(event, context):
    task = "This Function is created as part of a task for using terraform and Ansible with AWS Lambda Function"
    return task