def hello(event, context):
    print("UMAR KHASIM AJEKA first terraform function for CIL COHORT 4")