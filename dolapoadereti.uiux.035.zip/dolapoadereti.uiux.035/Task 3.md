# Redesigned dribbble projects

_Here's a link the figma file for the redesigned dribble projects_

https://www.figma.com/file/NExOMSj769HVtwVC8GSkZn/Dribble-Page-Redesign?node-id=0%3A1