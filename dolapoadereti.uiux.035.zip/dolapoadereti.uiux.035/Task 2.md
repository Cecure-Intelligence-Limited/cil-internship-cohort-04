## Mobile screens of Instagram UI (mid-fidelity wireframe)

_Here's a link the figma file for the instagram wireframe_

https://www.figma.com/file/uNGONicnNxM9kgJlhSxqkD/Instagram-Mid-fidelity-wireframe?node-id=0%3A1

<br>

## Low fidelity wireframe for Slack web UI (Landing screen and chat interface)

_Here's a link the figma file for Slack wireframe_

https://www.figma.com/file/kJCZfFJSz5l8osEF9JqFdy/Slack-Low-fidelity-wireframe?node-id=0%3A1