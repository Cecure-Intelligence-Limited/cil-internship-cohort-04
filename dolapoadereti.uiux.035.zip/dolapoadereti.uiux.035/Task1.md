# User Persona Task

_Here's a link the figma file for the user personas_

https://www.figma.com/file/5jzNgqJ44emayoRtxxAXLG/User-persona-task?node-id=0%3A1